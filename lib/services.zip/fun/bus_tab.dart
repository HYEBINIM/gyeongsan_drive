// lib/fun/bus_tab.dart
import 'package:flutter/material.dart';
import 'package:flutter_naver_map/flutter_naver_map.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:math' as math;
import '../models/bus_stop.dart';
import '../services/api_service.dart';

class BusTab extends StatefulWidget {
  const BusTab({Key? key}) : super(key: key);

  @override
  State<BusTab> createState() => _BusTabState();
}

class _BusTabState extends State<BusTab> {
  final ApiService _apiService = ApiService();
  
  // 디자인 상수 (current_location_tab.dart와 동일)
  static const Color _primaryColor = Color(0xFF00C853);
  static const Color _cardColor = Colors.white;
  static const Color _textPrimaryColor = Color(0xFF212121);
  static const Color _textSecondaryColor = Color(0xFF757575);
  static const double _largeBorderRadius = 12.0;
  
  NaverMapController? _mapController;
  List<BusStop> _busStops = [];
  bool _isLoading = true;
  String _errorMessage = '';
  Position? _currentPosition;
  BusStop? _selectedBusStop;
  int _selectedIndex = -1;
  
  final PageController _pageController = PageController(viewportFraction: 0.85);
  static const double _searchRadius = 3.0; // 고정 3km
  
  NLatLng? _lastSearchCenter;
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  Future<void> _initializeMap() async {
    await _getCurrentLocation();
    if (mounted) {
      await _loadNearbyBusStops();
    }
  }

  Future<void> _getCurrentLocation() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _errorMessage = '위치 서비스가 비활성화되어 있습니다.';
          _isLoading = false;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() {
            _errorMessage = '위치 권한이 거부되었습니다.';
            _isLoading = false;
          });
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        setState(() {
          _errorMessage = '위치 권한이 영구적으로 거부되었습니다.\n설정에서 권한을 허용해주세요.';
          _isLoading = false;
        });
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _currentPosition = position;
        _lastSearchCenter = NLatLng(position.latitude, position.longitude);
      });

      // 실시간 위치 업데이트
      Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 10,
        ),
      ).listen((Position position) {
        if (mounted) {
          setState(() {
            _currentPosition = position;
          });
          _updateCurrentLocationMarker();
        }
      });

    } catch (e) {
      setState(() {
        _errorMessage = '위치를 가져오는 중 오류가 발생했습니다: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadNearbyBusStops({NLatLng? center}) async {
    if (_isSearching) return;
    
    final searchCenter = center ?? _lastSearchCenter;
    if (searchCenter == null) return;

    setState(() {
      _isSearching = true;
    });

    try {
      final busStops = await _apiService.fetchNearbyBusStops(
        lat: searchCenter.latitude,
        lon: searchCenter.longitude,
        radiusKm: _searchRadius.toInt(),
      );

      if (mounted) {
        setState(() {
          _busStops = busStops;
          _isLoading = false;
          _isSearching = false;
          _lastSearchCenter = searchCenter;
          _selectedBusStop = null;
          _selectedIndex = -1;
        });

        if (_mapController != null) {
          await _updateMapMarkers();
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = '버스 정류장을 불러오는 중 오류가 발생했습니다: $e';
          _isLoading = false;
          _isSearching = false;
        });
      }
    }
  }

  Future<void> _updateMapMarkers() async {
    if (_mapController == null) return;

    await _mapController!.clearOverlays();

    // 현재 위치 표시 (파란 원)
    await _updateCurrentLocationMarker();

    // 버스 정류장 마커 추가 (커스텀 디자인)
    for (int i = 0; i < _busStops.length; i++) {
      final busStop = _busStops[i];
      final isSelected = _selectedBusStop?.id == busStop.id;
      
      // 커스텀 마커 위젯 생성
      final markerWidget = _buildCustomMarker(isSelected);
      
      final marker = NMarker(
        id: 'bus_stop_${busStop.id}',
        position: NLatLng(busStop.lat, busStop.lon),
      );

      // 커스텀 위젯을 마커 아이콘으로 설정
      final markerIcon = await NOverlayImage.fromWidget(
        widget: markerWidget,
        size: const Size(32, 32), // 마커 크기 40에서 32로 축소
        context: context,
      );
      
      marker.setIcon(markerIcon);

      marker.setOnTapListener((NMarker marker) {
        setState(() {
          _selectedBusStop = busStop;
          _selectedIndex = i;
        });
        
        _pageController.animateToPage(
          i,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
        
        _updateMapMarkers();
        
        return true;
      });

      await _mapController!.addOverlay(marker);
    }
  }

  Widget _buildCustomMarker(bool isSelected) {
    return Container(
      width: 32, // 크기 40에서 32로 축소
      height: 32,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white,
        border: Border.all(
          color: isSelected ? Colors.blue : const Color(0xFF66BB6A), // 선택 시 파란색
          width: isSelected ? 2.5 : 2, // 테두리 두께도 약간 축소
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isSelected
                ? [
                    Colors.blue.withOpacity(0.9), // 선택 시 파란색
                    Colors.blue,
                  ]
                : [
                    const Color(0xFF66BB6A).withOpacity(0.9),
                    const Color(0xFF66BB6A),
                  ],
          ),
        ),
        child: Center(
          child: Icon(
            Icons.directions_bus_rounded,
            color: Colors.white,
            size: 15,
          ),
        ),
      ),
    );
  }

  Future<void> _updateCurrentLocationMarker() async {
    if (_mapController == null || _currentPosition == null) return;

    // 파란색 원 (외곽)
    final outerCircle = NCircleOverlay(
      id: 'current_location_outer',
      center: NLatLng(_currentPosition!.latitude, _currentPosition!.longitude),
      radius: 30,
      color: Colors.blue.withOpacity(0.2),
      outlineColor: Colors.transparent,
      outlineWidth: 0,
    );

    await _mapController!.addOverlay(outerCircle);

    // 파란색 원 (내부) - 크기 10x10
    final innerCircle = NCircleOverlay(
      id: 'current_location_inner',
      center: NLatLng(_currentPosition!.latitude, _currentPosition!.longitude),
      radius: 10,
      color: Colors.blue,
      outlineColor: Colors.white,
      outlineWidth: 2,
    );

    await _mapController!.addOverlay(innerCircle);
  }

  void _onCameraChange(NCameraUpdateReason reason, bool isAnimated) {
    // 사용자가 지도를 이동했을 때만 재검색
    if (reason == NCameraUpdateReason.gesture) {
      _mapController?.getCameraPosition().then((cameraPosition) {
        final currentCenter = cameraPosition.target;
        
        // 마지막 검색 위치와의 거리 계산
        if (_lastSearchCenter != null) {
          final distance = _calculateDistance(
            _lastSearchCenter!.latitude,
            _lastSearchCenter!.longitude,
            currentCenter.latitude,
            currentCenter.longitude,
          );
          
          // 500m 이상 이동했을 때만 재검색
          if (distance > 0.5) {
            _loadNearbyBusStops(center: currentCenter);
          }
        }
      });
    }
  }

  double _calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371; // km
    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);
    
    final a = 
      math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_toRadians(lat1)) * math.cos(_toRadians(lat2)) *
      math.sin(dLon / 2) * math.sin(dLon / 2);
    
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    
    return earthRadius * c;
  }

  double _toRadians(double degree) {
    return degree * math.pi / 180;
  }

  @override
  Widget build(BuildContext context) {
    if (_errorMessage.isNotEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline,
                size: 64,
                color: _textSecondaryColor,
              ),
              const SizedBox(height: 16),
              Text(
                _errorMessage,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                  color: _textPrimaryColor,
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _initializeMap,
                icon: const Icon(Icons.refresh),
                label: const Text('다시 시도'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(_largeBorderRadius),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_currentPosition == null) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(_primaryColor),
            ),
            SizedBox(height: 16),
            Text('현재 위치를 가져오는 중...'),
          ],
        ),
      );
    }

    return Stack(
      children: [
        // 네이버 지도
        NaverMap(
          options: NaverMapViewOptions(
            initialCameraPosition: NCameraPosition(
              target: NLatLng(_currentPosition!.latitude, _currentPosition!.longitude),
              zoom: 15,
              bearing: 0,
              tilt: 0,
            ),
            indoorEnable: true,
            locationButtonEnable: true,
            consumeSymbolTapEvents: false,
          ),
          onMapReady: (controller) async {
            _mapController = controller;
            print('네이버 지도 준비 완료');
            
            await _updateMapMarkers();
            
            setState(() {
              _isLoading = false;
            });
          },
          onCameraChange: _onCameraChange,
        ),

        // 하단 패널 (current_location_tab.dart 스타일)
        if (_busStops.isNotEmpty)
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _buildBottomPanel(),
          ),

        // 로딩 인디케이터
        if (_isSearching)
          Positioned(
            top: 16,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(_primaryColor),
                      ),
                    ),
                    SizedBox(width: 8),
                    Text(
                      '정류장 검색 중...',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildBottomPanel() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 헤더
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '주변 정류장',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: _textPrimaryColor,
                  ),
                ),
                Text(
                  '${_busStops.length}개',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: _primaryColor,
                  ),
                ),
              ],
            ),
          ),
          
          // 정류장 리스트 (가로 스크롤)
          SizedBox(
            height: 180,
            child: PageView.builder(
              controller: _pageController,
              onPageChanged: (index) {
                setState(() {
                  _selectedBusStop = _busStops[index];
                  _selectedIndex = index;
                });
                
                // 지도 카메라 이동
                _mapController?.updateCamera(
                  NCameraUpdate.scrollAndZoomTo(
                    target: NLatLng(_busStops[index].lat, _busStops[index].lon),
                    zoom: 16,
                  ),
                );
                
                // 마커 색상 업데이트
                _updateMapMarkers();
              },
              itemCount: _busStops.length,
              itemBuilder: (context, index) {
                return _buildBusStopCard(_busStops[index], index);
              },
            ),
          ),
          
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildBusStopCard(BusStop busStop, int index) {
    final isSelected = _selectedIndex == index;
    final String distanceText = busStop.distanceKm != null 
        ? busStop.getDistanceText() 
        : '거리 미정';
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(_largeBorderRadius),
        border: isSelected 
            ? Border.all(color: Colors.blue, width: 2) // 선택 시 파란색 테두리
            : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isSelected ? 0.15 : 0.05),
            blurRadius: isSelected ? 12 : 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 상단 - 아이콘 영역
          Container(
            height: 70,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isSelected
                    ? [
                        Colors.blue.withOpacity(0.15), // 선택 시 파란색
                        Colors.blue.withOpacity(0.08),
                      ]
                    : [
                        const Color(0xFF66BB6A).withOpacity(0.15),
                        const Color(0xFF66BB6A).withOpacity(0.08),
                      ],
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(_largeBorderRadius),
                topRight: Radius.circular(_largeBorderRadius),
              ),
            ),
            child: Stack(
              children: [
                // 순위 뱃지
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: index < 3 ? _primaryColor : _textSecondaryColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '${index + 1}위',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                // 중앙 버스 아이콘
                Center(
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.directions_bus_rounded,
                      size: 24,
                      color: isSelected ? Colors.blue : const Color(0xFF66BB6A), // 선택 시 파란색
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // 하단 - 정보 영역
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 정류장명
                  Text(
                    busStop.stopName,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                      color: _textPrimaryColor,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  
                  // 도시명
                  Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        size: 12,
                        color: _textSecondaryColor,
                      ),
                      const SizedBox(width: 2),
                      Expanded(
                        child: Text(
                          busStop.cityName,
                          style: TextStyle(
                            color: _textSecondaryColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w400,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  
                  const Spacer(),
                  
                  // 하단 - 거리 정보
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: _primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.navigation,
                          size: 10,
                          color: _primaryColor,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          distanceText,
                          style: TextStyle(
                            color: _primaryColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _mapController?.dispose();
    super.dispose();
  }
}