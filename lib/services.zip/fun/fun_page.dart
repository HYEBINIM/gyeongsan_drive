// lib/fun/fun_page.dart
import 'package:flutter/material.dart';
import 'current_location_tab.dart'; 
import 'bus_tab.dart';

/// '놀거리' 탭의 메인 화면 위젯 (DefaultTabController 포함)
class FunPage extends StatelessWidget {
  const FunPage({super.key});

  @override
  Widget build(BuildContext context) {
    final double topPadding = MediaQuery.of(context).padding.top;
    
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(48.0 + topPadding),
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                SizedBox(height: topPadding),
                // 탭바
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                        color: const Color(0xFFE0E0E0),
                        width: 1,
                      ),
                    ),
                  ),
                  child: TabBar(
                    indicatorColor: const Color(0xFF00C853),
                    indicatorWeight: 3,
                    indicatorSize: TabBarIndicatorSize.tab,
                    labelColor: const Color(0xFF00C853),
                    unselectedLabelColor: const Color(0xFF757575),
                    labelStyle: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                    unselectedLabelStyle: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                    tabs: const [
                      Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.location_on, size: 18),
                            SizedBox(width: 6),
                            Text('현위치에서 떠나기'),
                          ],
                        ),
                      ),
                      Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.directions_bus, size: 18),
                            SizedBox(width: 6),
                            Text('버스타고 떠나기'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        body: const TabBarView(
          physics: NeverScrollableScrollPhysics(), // 스와이프 비활성화
          children: [
            CurrentLocationTab(), 
            BusTab(), 
          ],
        ),
      ),
    );
  }
}