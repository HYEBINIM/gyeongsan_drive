// lib/fun/place_detail_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_naver_map/flutter_naver_map.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/place.dart';
import 'navigation_screen.dart';

/// 장소 상세 정보 및 네이버 지도 화면
class PlaceDetailScreen extends StatefulWidget {
  final Place place;

  const PlaceDetailScreen({
    super.key,
    required this.place,
  });

  @override
  State<PlaceDetailScreen> createState() => _PlaceDetailScreenState();
}

class _PlaceDetailScreenState extends State<PlaceDetailScreen> {
  NaverMapController? _mapController;
  final DraggableScrollableController _sheetController = 
      DraggableScrollableController();
  
  // 디자인 상수
  static const Color _primaryColor = Color(0xFF00C853);
  static const Color _accentColor = Color(0xFFFF5252);
  static const Color _backgroundColor = Color(0xFFF5F5F5);
  static const Color _cardColor = Colors.white;
  static const Color _textPrimaryColor = Color(0xFF212121);
  static const Color _textSecondaryColor = Color(0xFF757575);
  
  @override
  void dispose() {
    _sheetController.dispose();
    super.dispose();
  }

  /// location 필드에서 위도, 경도 파싱 ("위도,경도" 형식)
  (double?, double?) _parseLocation() {
    try {
      final parts = widget.place.location.split(',');
      if (parts.length == 2) {
        final lat = double.tryParse(parts[0].trim());
        final lng = double.tryParse(parts[1].trim());
        
        if (lat != null && lng != null) {
          print('좌표 파싱 성공: 위도=$lat, 경도=$lng');
          return (lat, lng);
        }
      }
      print('좌표 파싱 실패: location=${widget.place.location}');
    } catch (e) {
      print('좌표 파싱 오류: $e');
    }
    return (null, null);
  }

  /// 내비게이션 화면으로 이동
  void _startNavigation() {
    final (lat, lng) = _parseLocation();
    if (lat == null || lng == null) {
      _showErrorSnackBar('목적지 위치 정보를 찾을 수 없습니다.');
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NavigationScreen(
          destinationName: widget.place.name,
          destinationLat: lat,
          destinationLng: lng,
        ),
      ),
    );
  }

  /// 전화 걸기
  Future<void> _makePhoneCall(String phoneNumber) async {
    final uri = Uri.parse('tel:$phoneNumber');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      _showErrorSnackBar('전화를 걸 수 없습니다.');
    }
  }

  /// 에러 스낵바 표시
  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: _accentColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final (lat, lng) = _parseLocation();
    
    if (lat == null || lng == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.place.name),
          backgroundColor: _cardColor,
          foregroundColor: _textPrimaryColor,
          elevation: 0,
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.location_off,
                  size: 64,
                  color: _textSecondaryColor,
                ),
                const SizedBox(height: 16),
                Text(
                  '위치 정보를 찾을 수 없습니다.',
                  style: TextStyle(
                    fontSize: 16,
                    color: _textPrimaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      body: Stack(
        children: [
          // 네이버 지도
          NaverMap(
            options: NaverMapViewOptions(
              initialCameraPosition: NCameraPosition(
                target: NLatLng(lat, lng),
                zoom: 15,
                bearing: 0,
                tilt: 0,
              ),
              mapType: NMapType.basic,
              activeLayerGroups: [NLayerGroup.building, NLayerGroup.transit],
              locale: const Locale('ko'),
            ),
            onMapReady: (controller) {
              _mapController = controller;
              
              final marker = NMarker(
                id: 'place_marker',
                position: NLatLng(lat, lng),
              );
              
              final infoWindow = NInfoWindow.onMarker(
                id: marker.info.id,
                text: widget.place.name,
              );
              
              marker.setOnTapListener((NMarker marker) {
                _sheetController.animateTo(
                  0.6,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              });
              
              controller.addOverlay(marker);
              marker.openInfoWindow(infoWindow);
            },
          ),

          // 상단 앱바
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                      color: _textPrimaryColor,
                    ),
                    Expanded(
                      child: Text(
                        widget.place.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: _textPrimaryColor,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                ),
              ),
            ),
          ),

          // 하단 정보 패널
          DraggableScrollableSheet(
            controller: _sheetController,
            initialChildSize: 0.35,
            minChildSize: 0.2,
            maxChildSize: 0.8,
            snap: true,
            snapSizes: const [0.35, 0.6],
            builder: (context, scrollController) {
              return Container(
                decoration: BoxDecoration(
                  color: _cardColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: ListView(
                  controller: scrollController,
                  padding: EdgeInsets.zero,
                  children: [
                    // 드래그 핸들
                    Center(
                      child: Container(
                        margin: const EdgeInsets.only(top: 12, bottom: 8),
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 장소명
                          Text(
                            widget.place.name,
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              color: _textPrimaryColor,
                              height: 1.2,
                            ),
                          ),
                          const SizedBox(height: 12),

                          // 카테고리
                          if (widget.place.category.isNotEmpty) 
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.orange.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.restaurant,
                                    size: 14,
                                    color: Colors.orange.shade700,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    widget.place.category,
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.orange.shade700,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                          const SizedBox(height: 20),

                          // 위치 정보
                          _buildInfoRow(
                            Icons.location_on,
                            '주소',
                            widget.place.content.isNotEmpty 
                                ? widget.place.content 
                                : widget.place.local,
                          ),
                          const SizedBox(height: 16),

                          // 액션 버튼들
                          Row(
                            children: [
                              Expanded(
                                child: _buildActionButton(
                                  icon: Icons.navigation,
                                  label: '길찾기',
                                  color: _primaryColor,
                                  onTap: _startNavigation,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _buildActionButton(
                                  icon: Icons.share,
                                  label: '공유',
                                  color: Colors.blue,
                                  onTap: () {
                                    _showErrorSnackBar('공유 기능은 준비중입니다.');
                                  },
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 24),

                          // 상세 정보 섹션
                          Text(
                            '상세 정보',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: _textPrimaryColor,
                            ),
                          ),
                          const SizedBox(height: 12),

                          // 검색 횟수
                          _buildDetailItem(
                            icon: Icons.trending_up,
                            title: '인기도',
                            value: '검색 ${widget.place.searchNum}회',
                            iconColor: _accentColor,
                          ),

                          const SizedBox(height: 12),

                          // ID 정보
                          _buildDetailItem(
                            icon: Icons.tag,
                            title: 'ID',
                            value: '#${widget.place.id}',
                            iconColor: _primaryColor,
                          ),

                          // 전화번호
                          if (widget.place.telNumber.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            GestureDetector(
                              onTap: () => _makePhoneCall(widget.place.telNumber),
                              child: _buildDetailItem(
                                icon: Icons.phone,
                                title: '전화번호',
                                value: widget.place.telNumber,
                                iconColor: Colors.green,
                              ),
                            ),
                          ],

                          const SizedBox(height: 24),

                          // 지도에서 크게 보기 버튼
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () {
                                _sheetController.animateTo(
                                  0.2,
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeInOut,
                                );
                              },
                              icon: const Icon(Icons.map, size: 18),
                              label: const Text('지도 크게 보기'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: _primaryColor,
                                side: BorderSide(color: _primaryColor, width: 1.5),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  /// 정보 행 위젯
  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: _primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            size: 18,
            color: _primaryColor,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: _textSecondaryColor,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: _textPrimaryColor,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// 액션 버튼 위젯
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 상세 정보 아이템
  Widget _buildDetailItem({
    required IconData icon,
    required String title,
    required String value,
    required Color iconColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              size: 18,
              color: iconColor,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: _textSecondaryColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: _textPrimaryColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}