// /lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_naver_map/flutter_naver_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import '../services/location_service.dart';
import '../services/bus_api_service.dart';
import '../services/tourist_spot_service.dart';
import '../models/bus_stop.dart';
import '../models/tourist_spot.dart';
import '../widgets/bus_stop_bottom_sheet.dart';
import '../widgets/spot_list_bottom_sheet.dart';

/// 홈 스크린 - 지도 화면
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final LocationService _locationService = LocationService();
  final BusApiService _busApiService = BusApiService();
  final TouristSpotService _touristSpotService = TouristSpotService();

  NaverMapController? _mapController;
  Position? _currentPosition;
  List<BusStop> _nearbyBusStops = [];
  List<TouristSpot> _nearbySpots = [];
  bool _isLoading = true;
  bool _isTracking = true; // 위치 추적 상태

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  /// 지도 초기화
  Future<void> _initializeMap() async {
    try {
      setState(() => _isLoading = true);

      // 네이버 지도 SDK 초기화
      await NaverMapSdk.instance.initialize(
          onAuthFailed: (ex) {
            print('네이버 지도 인증 실패: $ex');
          },
      );

      // 현재 위치 가져오기
      final position = await _locationService.getCurrentLocation();
      if (position != null) {
        setState(() {
          _currentPosition = position;
        });

        // 주변 정류장 및 관광지 로드
        await _loadNearbyData();
      }
    } catch (e) {
      print('지도 초기화 오류: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// 주변 데이터 로드
  Future<void> _loadNearbyData() async {
    if (_currentPosition == null) return;

    try {
      // 주변 정류장 조회
      final busStops = await _busApiService.getNearbyBusStops(
        latitude: _currentPosition!.latitude,
        longitude: _currentPosition!.longitude,
        radius: 500,
      );

      // 주변 관광지 조회
      final spots = await _touristSpotService.getNearbySpots(
        latitude: _currentPosition!.latitude,
        longitude: _currentPosition!.longitude,
        radius: 2.0,
      );

      setState(() {
        _nearbyBusStops = busStops;
        _nearbySpots = spots;
      });

      // 지도에 마커 추가
      _addMarkersToMap();
    } catch (e) {
      print('주변 데이터 로드 오류: $e');
    }
  }

  /// 지도에 마커 추가
  void _addMarkersToMap() {
    if (_mapController == null) return;

    // TODO: 네이버 지도에 마커 추가 로직 구현
  }

  /// 정류장 마커 클릭 시
  void _onBusStopTap(BusStop busStop) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => BusStopBottomSheet(busStop: busStop),
    );
  }

  /// 주변 명소 보기
  void _showNearbySpots() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SpotListBottomSheet(spots: _nearbySpots),
    );
  }

  /// 현재 위치로 카메라 이동 및 추적 모드 활성화
  void _moveToCurrentLocation() {
    if (_mapController == null) return;

    try {
      // 위치 추적 모드를 활성화하면 자동으로 현재 위치로 이동합니다
      _mapController!.setLocationTrackingMode(NLocationTrackingMode.follow);
      
      setState(() {
        _isTracking = true;
      });
    } catch (e) {
      print('위치 이동 오류: $e');
    }
  }

  /// 카메라 이동 이벤트 처리
  void _onCameraChange(NCameraUpdateReason reason, bool animated) {
    // 사용자가 수동으로 지도를 이동한 경우 추적 모드 해제
    if (reason == NCameraUpdateReason.gesture) {
      setState(() {
        _isTracking = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      body: Stack(
        children: [
          // 네이버 지도
          _currentPosition != null
              ? NaverMap(
                  options: NaverMapViewOptions(
                    initialCameraPosition: NCameraPosition(
                      target: NLatLng(
                        _currentPosition!.latitude,
                        _currentPosition!.longitude,
                      ),
                      zoom: 15,
                    ),
                    locationButtonEnable: false,
                    consumeSymbolTapEvents: false,
                  ),
                  onMapReady: (controller) {
                    setState(() {
                      _mapController = controller;
                    });
                    
                    // 지도 준비 후 위치 추적 모드 활성화
                    try {
                      controller.setLocationTrackingMode(NLocationTrackingMode.follow);
                    } catch (e) {
                      print('위치 추적 모드 설정 오류: $e');
                    }
                    
                    _addMarkersToMap();
                  },
                  onCameraChange: _onCameraChange,
                )
              : const Center(
                  child: Text('위치 정보를 가져올 수 없습니다.'),
                ),

          // 상단 앱바
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    const Icon(Icons.directions_bus_rounded, color: Colors.blue),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '경산 버스 투어',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            '주변 정류장 ${_nearbyBusStops.length}개',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Colors.grey,
                                ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: _loadNearbyData,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // 커스텀 위치 버튼 (오른쪽 하단)
          Positioned(
            right: 16,
            bottom: 100,
            child: SafeArea(
              child: FloatingActionButton(
                onPressed: _moveToCurrentLocation,
                backgroundColor: Colors.white,
                elevation: 4,
                child: Icon(
                  _isTracking ? Icons.my_location : Icons.location_searching,
                  color: _isTracking 
                      ? Theme.of(context).colorScheme.primary 
                      : Colors.grey,
                ),
              ),
            ),
          ),

          // 하단 버튼들
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // 주변 명소 보기 버튼
                    ElevatedButton.icon(
                      onPressed: _showNearbySpots,
                      icon: const Icon(Icons.place),
                      label: Text('주변 명소 보기 (${_nearbySpots.length}개)'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Theme.of(context).colorScheme.primary,
                        minimumSize: const Size(double.infinity, 56),
                        elevation: 4,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}