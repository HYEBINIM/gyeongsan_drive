//lib/services/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/place.dart';
import '../models/event.dart';
import '../models/bus_stop.dart';

class ApiService {
  
  static const String _apiBaseUrl = 'http://211.58.207.209:2441/api/v1'; 
  
  static const String _naverSearchClientId = 'DEDaHo4JXKs6OoyE33nj'; 
  static const String _naverSearchClientSecret = 'vRviP6ootz';
  static const String _naverSearchApiBaseUrl = 'https://openapi.naver.com/v1/search';
  static const String _naverGeocodeClientId = 't14lkvxmuw'; 
  static const String _naverGeocodeClientSecret = 'niNPCTn2zud0jHMwfLpNVvDarGdmxlEGjyjqLIGM'; 
  static const String _naverGeocodeApiUrl = 'https://maps.apigw.ntruss.com/map-reversegeocode/v2/gc';
  
  String _cleanHtml(String html) {
    return html.replaceAll(RegExp(r'<[^>]*>|&[^;]+;'), '');
  }

  // --- 1. 현위치 역지오코딩 (기존 로직 유지) ---
  Future<String> reverseGeocode({required double lat, required double lon}) async {
    if (_naverGeocodeClientId == 'YOUR_NAVER_MAP_CLIENT_ID') { 
      print('네이버 지도 API 키를 설정해주세요. 기본값 경산으로 진행합니다.');
      return '경산'; 
    }
    
    final url = Uri.parse('$_naverGeocodeApiUrl?coords=$lon,$lat&output=json');

    try {
      final response = await http.get(
        url,
        headers: {
          'X-NCP-APIGW-API-KEY-ID': _naverGeocodeClientId, 
          'X-NCP-APIGW-API-KEY': _naverGeocodeClientSecret,
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(utf8.decode(response.bodyBytes));
        final results = data['results'] as List<dynamic>?;

        if (results != null && results.isNotEmpty) {
          final String area1Name = results[0]['region']['area1']['name'] as String;
          final String area2Name = results[0]['region']['area2']['name'] as String; 
          
          if (area2Name.contains('경산')) return '경산';
          
          if (area1Name.contains('대구')) return '대구';
          
          return results[0]['region']['area3']['name'] as String;
        } else {
          print('Naver Geocode API returned no results.');
          return '경산'; 
        }
      } else {
        print('Naver Geocode API Failed: ${response.statusCode}');
        return '경산'; 
      }
    } catch (e) {
      print('Geocode Request error: $e');
      return '경산'; 
    }
  }

  // --- 2. 현위치 기반 TOP 5 장소 데이터 가져오기 (기존 로직 유지) ---
  Future<List<Place>> fetchHotplaces({required String locationName}) async {
    print('DB 조회 로직으로 전환됨: fetchHotplaces를 DB에서 상위 5개만 가져오도록 수정합니다.');
    
    final List<Map<String, dynamic>> dbResults = await _fetchPlacesFromDatabase(
      locationName: locationName,
    );
    
    final int limit = dbResults.length.clamp(0, 5); 
    
    List<Place> top5Places = [];
    for (int i = 0; i < limit; i++) {
      final item = dbResults[i];
      
      // DB 응답을 Place 모델로 변환
      top5Places.add(Place(
        id: item['id'] ?? (i + 1),
        name: item['name'] as String? ?? '이름 없음',
        location: item['location'] as String? ?? '',
        local: item['local'] as String? ?? locationName,
        category: item['category'] as String? ?? '',
        content: item['content'] as String? ?? '',
        searchNum: item['search_num'] ?? (dbResults.length - i) * 10,
        telNumber: item['tel_number'] as String? ?? '',
        type: item['type'] ?? 0,
        hashtags: ['#${item['category'] ?? '음식점'}'],
      ));
    }
    
    return top5Places;
  }

  Future<List<Map<String, dynamic>>> _fetchPlacesFromDatabase({
    required String locationName,
  }) async {
    final url = Uri.parse('$_apiBaseUrl/place/top?location=$locationName'); 

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final dynamic responseData = json.decode(utf8.decode(response.bodyBytes));
        
        // 응답이 배열인지 객체인지 확인
        List<dynamic> places;
        if (responseData is List) {
          places = responseData;
        } else if (responseData is Map && responseData.containsKey('places')) {
          places = responseData['places'] as List;
        } else {
          print('DB API 응답 형식 오류');
          return [];
        }
        
        print('DB API 조회 성공. 지역: $locationName, 조회된 장소 수: ${places.length}');
        return places.cast<Map<String, dynamic>>();

      } else {
        print('DB API 호출 실패 (Status: ${response.statusCode}). Response: ${utf8.decode(response.bodyBytes)}');
        return []; 
      }
    } catch (e) {
      print('DB API 요청 오류: $e');
      return []; 
    }
  }

  Future<List<Place>> fetchTourContentList({
    required Set<String> uniquePlaceNames,
    required int targetCount,
    required int currentCount,
    required String locationName, 
  }) async {
    return [];
  }


  // --- 4. DB 조회 데이터를 Place 모델로 변환 및 최종 목록 생성 (TOP 100) (기존 로직 유지) ---
  Future<List<Place>> fetchHotplacesList({
    required String locationName, 
    required List<Place> existingPlaces, 
  }) async {
    const int targetCount = 100;
    
    final List<Map<String, dynamic>> dbResults = await _fetchPlacesFromDatabase(
      locationName: locationName,
    );
    
    List<Place> finalPlaces = [];
    for (int i = 0; i < dbResults.length; i++) {
      final item = dbResults[i];
      
      // DB 응답을 Place 모델로 변환
      finalPlaces.add(Place(
        id: item['id'] ?? (i + 1),
        name: item['name'] as String? ?? '이름 없음',
        location: item['location'] as String? ?? '',
        local: item['local'] as String? ?? locationName,
        category: item['category'] as String? ?? '',
        content: item['content'] as String? ?? '',
        searchNum: item['search_num'] ?? (dbResults.length - i) * 10,
        telNumber: item['tel_number'] as String? ?? '',
        type: item['type'] ?? 0,
        hashtags: ['#${item['category'] ?? '음식점'}'],
      ));
    }
    
    List<Place> result = finalPlaces.sublist(0, finalPlaces.length.clamp(0, targetCount));

    print('\n--- 최종 TOP ${result.length} 장소 목록 출력 (DB 조회, search_num 기준) ---');
    for (int i = 0; i < result.length; i++) {
      final place = result[i];
      print('${i + 1}위: ${place.name} (검색횟수: ${place.searchNum})');
    }
    print('---------------------------------------------------\n');

    return result;
  }
  
  // --- 5. 내 주변 장소 데이터 가져오기 (기존 로직 유지) ---
  Future<List<Place>> fetchNearbyPlaces({
    required double lat, 
    required double lon,
  }) async {
    // DB API에서 현위치 기반 가까운 장소 조회로 로직 변경
    final url = Uri.parse('$_apiBaseUrl/place/nearby?lat=$lat&lon=$lon');
    
    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final dynamic responseData = json.decode(utf8.decode(response.bodyBytes));
        
        // 응답이 배열인지 객체인지 확인
        List<dynamic> places;
        if (responseData is List) {
          places = responseData;
        } else if (responseData is Map && responseData.containsKey('places')) {
          places = responseData['places'] as List;
        } else {
          print('Nearby API 응답 형식 오류');
          return [];
        }
        
        List<Place> placesList = [];
        for (int i = 0; i < places.length; i++) {
            final item = places[i];
            
            // distance_km 필드를 사용하여 거리 정보 표시 (Haversine 공식 결과)
            double distanceKm = item['distance_km'] is double 
                ? item['distance_km'] 
                : (item['distance_km'] as int?)?.toDouble() ?? 0.0;
            
            // 거리 포맷팅: 1km 미만은 m, 이상은 km 단위로 표시
            String distanceText = distanceKm < 1 
                ? '${(distanceKm * 1000).toStringAsFixed(0)}m' 
                : '${distanceKm.toStringAsFixed(1)}km'; 

            // 해시태그 목록에 거리 정보와 카테고리 추가
            List<String> hashtags = [distanceText, '#${item['category'] ?? '음식점'}']; 

            placesList.add(Place(
              id: item['id'] ?? (i + 1),
              name: item['name'] as String? ?? '이름 없음',
              location: item['location'] as String? ?? '',
              local: item['local'] as String? ?? '',
              category: item['category'] as String? ?? '',
              content: item['content'] as String? ?? '',
              searchNum: item['search_num'] ?? 0,
              telNumber: item['tel_number'] as String? ?? '',
              type: item['type'] ?? 0,
              hashtags: hashtags,
            ));
        }
        
        print('내 주변 장소 조회 성공: ${placesList.length}개');
        return placesList;
      } else {
        print('DB Nearby API Failed: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      print('Nearby Request error: $e');
      return [];
    }
  }

  // --- 6. 문화 행사 데이터 가져오기 (기존 로직 유지) ---
  /// 현위치 기반 문화 행사 조회
  Future<List<Event>> fetchEvents({
    required double lat,
    required double lon,
    String? startDate,
    String? endDate,
  }) async {
    // 쿼리 파라미터 구성
    String queryParams = 'lat=$lat&lon=$lon';
    
    if (startDate != null) {
      queryParams += '&start_date=$startDate';
    }
    
    if (endDate != null) {
      queryParams += '&end_date=$endDate';
    }
    
    final url = Uri.parse('$_apiBaseUrl/event/nearby?$queryParams');
    
    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final dynamic responseData = json.decode(utf8.decode(response.bodyBytes));
        
        // 응답이 배열인지 객체인지 확인
        List<dynamic> events;
        if (responseData is List) {
          events = responseData;
        } else if (responseData is Map && responseData.containsKey('events')) {
          events = responseData['events'] as List;
        } else {
          print('Events API 응답 형식 오류');
          return [];
        }
        
        List<Event> eventsList = [];
        for (int i = 0; i < events.length; i++) {
          final item = events[i];
          
          eventsList.add(Event(
            contentId: item['contentid'] as String? ?? '',
            title: item['title'] as String? ?? '제목 없음',
            addr1: item['addr1'] as String? ?? '',
            addr2: item['addr2'] as String? ?? '',
            mapX: item['mapx'] as String? ?? '',
            mapY: item['mapy'] as String? ?? '',
            firstImage: item['firstimage'] as String? ?? '',
            tel: item['tel'] as String? ?? '',
            areaCode: item['areacode'] as String? ?? '',
            sigunguCode: item['sigungucode'] as String? ?? '',
            eventStartDate: item['eventstartdate'] as String?,
            eventEndDate: item['eventenddate'] as String?,
            progressType: item['progresstype'] as String?,
            festivalType: item['festivaltype'] as String?,
          ));
        }
        
        print('문화 행사 조회 성공: ${eventsList.length}개');
        return eventsList;
      } else if (response.statusCode == 404) {
        // 404 에러는 API가 아직 구현되지 않은 것이므로 조용히 빈 목록 반환
        print('Events API 미구현 (404) - 빈 목록 반환');
        return [];
      } else {
        print('Events API Failed: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      // 네트워크 에러 등도 조용히 처리
      print('Events Request error: $e');
      return [];
    }
  }

  // --- 7. 내 주변 버스 정류장 데이터 가져오기 (Flask 서버 엔드포인트 사용) ---
  /// 현위치 기반 주변 버스 정류장 조회
  /// Flask 서버의 /api/v1/bus/nearby 엔드포인트 사용
  Future<List<BusStop>> fetchNearbyBusStops({
    required double lat, 
    required double lon,
    int radiusKm = 1, // 기본 검색 반경 1km
  }) async {
    final url = Uri.parse('$_apiBaseUrl/bus/nearby?lat=$lat&lon=$lon&radius=$radiusKm');
    
    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final dynamic responseData = json.decode(utf8.decode(response.bodyBytes));
        
        // Flask 서버는 배열 형태로 응답
        List<dynamic> stops;
        if (responseData is List) {
          stops = responseData;
        } else if (responseData is Map && responseData.containsKey('stops')) {
          stops = responseData['stops'] as List;
        } else {
          print('Bus Stops API 응답 형식 오류');
          return [];
        }
        
        List<BusStop> stopsList = stops.map((item) => BusStop.fromJson(item)).toList();
        
        print('내 주변 버스 정류장 조회 성공: ${stopsList.length}개');
        return stopsList;
      } else if (response.statusCode == 404) {
        print('Bus Stops API 미구현 (404) - 빈 목록 반환');
        return [];
      } else {
        print('Bus Stops API Failed: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      print('Bus Stops Request error: $e');
      return [];
    }
  }
}